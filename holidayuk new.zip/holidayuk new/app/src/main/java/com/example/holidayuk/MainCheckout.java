package com.example.holidayuk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainCheckout extends AppCompatActivity {

    ImageView home_button, profile_button;
    RelativeLayout btnCredit, btnDompet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        btnCredit= (RelativeLayout) findViewById(R.id.credit);
        btnCredit.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainCheckout.this,MainCheckoutCard.class);
                startActivity(intent);
            }
        });

        btnDompet= (RelativeLayout) findViewById(R.id.dompet);
        btnDompet.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainCheckout.this,MainCheckoutDompet.class);
                startActivity(intent);
            }
        });

        home_button= (ImageView) findViewById(R.id.footer_home);
        home_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainCheckout.this,MainBeranda.class);
                startActivity(intent);
            }
        });

        profile_button= (ImageView) findViewById(R.id.footer_user);
        profile_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainCheckout.this,MainProfile.class);
                startActivity(intent);
            }
        });
    }
}
