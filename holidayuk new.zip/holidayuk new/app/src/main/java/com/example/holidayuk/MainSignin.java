package com.example.holidayuk;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainSignin extends AppCompatActivity {

    RelativeLayout sign_in_button;
    private EditText editEmail, editPassword;
    private FirebaseUser firebaseUser;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        editEmail = findViewById(R.id.input_email);
        editPassword = findViewById(R.id.input_password);

        editEmail.setOnEditorActionListener(editorListener);
        editPassword.setOnEditorActionListener(editorListener);
        mAuth = FirebaseAuth.getInstance();

        sign_in_button= (RelativeLayout) findViewById(R.id.btn_singin);
        sign_in_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                if (editEmail.getText().length()>0 && editPassword.getText().length()>0 ) {
                    login(editEmail.getText().toString(), editPassword.getText().toString());

                } else {
                    Toast.makeText(getApplicationContext(), "Tolong lengkapi data!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void login(String email, String password){
        //CODING LOGIN
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful() && task.getResult()!=null){
                    if (task.getResult().getUser()!=null){
                        startActivity(new Intent(MainSignin.this, MainBeranda.class));
                        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                        Toast.makeText(getApplicationContext(),"Berhasil masuk", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(getApplicationContext(),"Gagal masuk", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(),"Gagal masuk", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private final TextView.OnEditorActionListener editorListener = new TextView.OnEditorActionListener() {
        @Override
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            switch (actionId) {
                case EditorInfo.IME_ACTION_NEXT:
                case EditorInfo.IME_ACTION_GO:
            } return false;
        }
    };
}
