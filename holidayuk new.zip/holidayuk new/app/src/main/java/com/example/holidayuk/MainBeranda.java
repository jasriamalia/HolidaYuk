package com.example.holidayuk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainBeranda extends AppCompatActivity {

    ImageView profile_button;
    RelativeLayout checkout_button, bali_button, lombok_button, yogya_button, jateng_button, raja_button, komodo_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda);

        profile_button= (ImageView) findViewById(R.id.footer_user);
        profile_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainBeranda.this,MainProfile.class);
                startActivity(intent);
            }
        });

        checkout_button= (RelativeLayout) findViewById(R.id.footer_cart);
        checkout_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainBeranda.this,MainCheckout.class);
                startActivity(intent);
            }
        });

        bali_button= (RelativeLayout) findViewById(R.id.bali_card);
        bali_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainBeranda.this,MainDeskripsiBali.class);
                startActivity(intent);
            }
        });

        lombok_button= (RelativeLayout) findViewById(R.id.lombok_card);
        lombok_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainBeranda.this,MainDeskripsiLombok.class);
                startActivity(intent);
            }
        });

        yogya_button= (RelativeLayout) findViewById(R.id.yogya_card);
        yogya_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainBeranda.this,MainDeskripsiYogya.class);
                startActivity(intent);
            }
        });

        jateng_button= (RelativeLayout) findViewById(R.id.jateng_card);
        jateng_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainBeranda.this,MainDeskripsiJateng.class);
                startActivity(intent);
            }
        });

        raja_button= (RelativeLayout) findViewById(R.id.raja_card);
        raja_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainBeranda.this,MainDeskripsiRaja.class);
                startActivity(intent);
            }
        });

        komodo_button= (RelativeLayout) findViewById(R.id.komodo_card);
        komodo_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainBeranda.this,MainDeskripsiKomodo.class);
                startActivity(intent);
            }
        });
    }
}
