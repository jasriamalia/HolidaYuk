package com.example.holidayuk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainProfile extends AppCompatActivity {


    ImageView home_button;
    RelativeLayout checkout_button;
    TextView textName, textEmail;
    private FirebaseUser firebaseUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        RelativeLayout btnlogout = findViewById(R.id.btn_logout);
        textName = findViewById(R.id.username);
        textEmail = findViewById(R.id.email);

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        if(firebaseUser!=null){
            textName.setText(firebaseUser.getDisplayName());
            textEmail.setText(firebaseUser.getEmail());
        } else {
            textName.setText("...");
            textEmail.setText("...");
        }

        home_button= (ImageView) findViewById(R.id.footer_home);
        home_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainProfile.this,MainBeranda.class);
                startActivity(intent);
            }
        });

        checkout_button= (RelativeLayout) findViewById(R.id.footer_cart);
        checkout_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainProfile.this,MainCheckout.class);
                startActivity(intent);
            }
        });

        btnlogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            finish();
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            Toast.makeText(getApplicationContext(),"Berhasil keluar dari akun", Toast.LENGTH_SHORT).show();
        });
    }
}
