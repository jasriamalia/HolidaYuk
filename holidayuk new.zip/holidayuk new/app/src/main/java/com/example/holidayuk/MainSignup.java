package com.example.holidayuk;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class MainSignup extends AppCompatActivity {

    RelativeLayout sign_up_button;
    private EditText editEmail,editUsername, editPassword, editPasswordCon;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        editUsername = findViewById(R.id.input_username);
        editEmail = findViewById(R.id.input_email);
        editPassword = findViewById(R.id.input_password);
        editPasswordCon = findViewById(R.id.input_password_conf);

        editUsername.setOnEditorActionListener(editorListener);
        editEmail.setOnEditorActionListener(editorListener);
        editPassword.setOnEditorActionListener(editorListener);
        editPasswordCon.setOnEditorActionListener(editorListener);

        mAuth = FirebaseAuth.getInstance();

        sign_up_button= (RelativeLayout) findViewById(R.id.btn_singin);
        sign_up_button.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                if (editUsername.getText().length()>0 && editEmail.getText().length()>0 && editPassword.getText().length()>0 && editPasswordCon.getText().length()>0){
                    if (editPassword.getText().toString().equals(editPasswordCon.getText().toString())){
                        register(editUsername.getText().toString(),editEmail.getText().toString(),editPassword.getText().toString());
                    } else {
                        Toast.makeText(getApplicationContext(), "Please enter the same password!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Please complete all data!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void register(String username, String email, String password){
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful() && task.getResult()!=null){
                    FirebaseUser firebaseUser = task.getResult().getUser();
                    if (firebaseUser!=null) {
                        UserProfileChangeRequest request = new UserProfileChangeRequest.Builder()
                                .setDisplayName(username)
                                .build();
                        firebaseUser.updateProfile(request).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                startActivity(new Intent(MainSignup.this, MainSignin.class));
                                Toast.makeText(MainSignup.this, "Registrasi berhasil, silahkan sign in untuk memulai!", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        });
                    } else {
                        Toast.makeText(getApplicationContext(),"Failed to register", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(getApplicationContext(), task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private final TextView.OnEditorActionListener editorListener = new TextView.OnEditorActionListener() {
        @Override
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            switch (actionId) {
                case EditorInfo.IME_ACTION_NEXT:
                case EditorInfo.IME_ACTION_GO:
            }
            return false;
        }
    };
}
